# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtGui, QtWidgets
print('starting imports')

from find_COR import COR_finder
from find_pixel_size import PixelSize_finder
from ask_once import ask_once
import tkinter.filedialog
import os


standard_path = "/mnt/raid/CT/"

if __name__ == "__main__":

    import sys
    app = QtWidgets.QApplication(sys.argv)

    path_klick = tkinter.filedialog.askopenfilename(title="Select one file of the scan", initialdir = standard_path)
    htap = path_klick[::-1]
    path_in = path_klick[0: len(htap) - htap.find('/') - 1: 1]
    file_name_parameter = path_in + '/parameter.csv'
    print(file_name_parameter)

    path_out = path_in + '_evaluation'
    if os.path.isdir(path_out) is False:
        os.mkdir(path_out)

    f = open(file_name_parameter, 'r')  # Reading scan-scheme parameters
    for line in f:
        line = line.strip()
        columns = line.split()
        print(columns[0])

        if str(columns[0]) == 'box_lateral_shift':
            box_lateral_shift = int(columns[1])
            print(columns[1])

    f.close()

    # ================================================================================================================ #
    print('prepare for showing ask_once')

    module_choice = ['interlaced_CT_16_bit_integer_test', 'interlaced_CT_16_bit_integer_movement_correction_test', 'interlaced_CT_normalization_only', 'interlaced_CT_32_bit_float_test']

    main_ask_once = ask_once(module_choice)
    main_ask_once.show()
    app.exec_()

    checkBox_save_normalized = main_ask_once.checkBox_save_normalized
    checkBox_classic_order = main_ask_once.checkBox_classic_order

    no_of_cores = main_ask_once.no_of_cores
    dark_field_value = main_ask_once.dark_field_value
    block_size = main_ask_once.block_size

    if main_ask_once.module_text == 'interlaced_CT_16_bit_integer_test':
        from interlaced_CT_16_bit_integer_test import CT_preview
    if main_ask_once.module_text == 'interlaced_CT_16_bit_integer_movement_correction_test':
        from interlaced_CT_16_bit_integer_movement_correction_test import CT_preview
    if main_ask_once.module_text == 'interlaced_CT_normalization_only':
        from interlaced_CT_normalization_only import CT_preview
    if main_ask_once.module_text == 'interlaced_CT_32_bit_float_test':
        from interlaced_CT_32_bit_float_test import CT_preview

    index_COR_1 = main_ask_once.index_COR_1
    index_COR_2 = main_ask_once.index_COR_2
    FF_index = main_ask_once.FF_index
    index_pixel_size_1 = main_ask_once.index_pixel_size_1
    index_pixel_size_2 = main_ask_once.index_pixel_size_2

    # ================================================================================================================ #
    print('prepare for showing COR_finder')

    main_COR_finder = COR_finder(path_klick, path_out, index_COR_1, index_COR_2, FF_index)
    value = main_COR_finder.show()

    print(value)
    app.exec_()
    COR = main_COR_finder.COR
    rotate = main_COR_finder.rotate
    print(COR)

    # ================================================================================================================ #
    if box_lateral_shift != 0:
        print('prepare for showing pixel_size_finder')
        main_find_pixel_size = PixelSize_finder(path_klick, path_out, index_pixel_size_1, index_pixel_size_2, FF_index)
        main_find_pixel_size.show()
        app.exec_()
        pixel_size = main_find_pixel_size.pixel_size
        print(pixel_size)
    else:
        pixel_size = 1
        print('no lateral shift')

    # ================================================================================================================ #
    print('prepare for showing CT-Preview')
    main_preview_CT = CT_preview(COR, rotate, pixel_size, path_klick, path_out, block_size, dark_field_value, no_of_cores, checkBox_save_normalized, checkBox_classic_order)#, algorithm, filter)
    main_preview_CT.show()
    app.exec_()


    print('call_programs DONE!')
    sys.exit(0)
    print('DONE')
