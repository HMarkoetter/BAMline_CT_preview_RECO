# ask_once
# reads asks for data that needs to be set before reconstruction

from PyQt5 import QtCore, QtGui, QtWidgets
import qimage2ndarray
from PyQt5.uic import loadUiType
import numpy
from PIL import Image
import os
import time
import tkinter.filedialog
from PyQt5.QtGui import QIcon, QPixmap
from scipy import ndimage

import sys

print('We are in ask_once.py now.')

Ui_ask_once_Window, Q_ask_once_Window = loadUiType('ask_once.ui')  # GUI vom Hauptfenster


class ask_once(Ui_ask_once_Window, Q_ask_once_Window):


    def __init__(self, module_choice):
        super(ask_once, self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.save_values)
        print('ask_once.py init')
        self.comboBox.addItems(module_choice)


    def save_values(self):

        self.block_size = self.block_size.value()
        self.dark_field_value = self.dark_field_value.value()
        self.no_of_cores = self.no_of_cores.value()
        self.index_COR_1 = self.index_COR_1.value()
        self.index_COR_2 = self.index_COR_2.value()
        self.FF_index = self.FF_index.value()
        self.index_pixel_size_1 = self.index_pixel_size_1.value()
        self.index_pixel_size_2 = self.index_pixel_size_2.value()
        self.checkBox_save_normalized = self.checkBox_save_normalized.isChecked()
        self.checkBox_classic_order = self.checkBox_classic_order.isChecked()
        self.module_text = self.comboBox.currentText()
        #self.algorithm_list = self.algorithm_list.currentText()
        #self.filter_list = self.filter_list.currentText()

        self.close()

